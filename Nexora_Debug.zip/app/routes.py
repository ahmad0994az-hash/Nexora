import os
import secrets

from flask import (
    render_template,
    request,
    send_from_directory,
    abort,
    url_for
)

from werkzeug.utils import secure_filename

from .database import db
from .models import File


def register_routes(app):

    UPLOAD_FOLDER = "uploads"

    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


    @app.route("/")
    def home():
        return render_template("index.html")


    @app.route("/upload", methods=["GET", "POST"])
    def upload():

        message = None
        share_url = None

        if request.method == "POST":

            uploaded_file = request.files.get("file")

            if uploaded_file and uploaded_file.filename:

                token = secrets.token_urlsafe(8)

                extension = os.path.splitext(uploaded_file.filename)[1]

                saved_name = token + extension

                save_path = os.path.join(
                    app.config["UPLOAD_FOLDER"],
                    saved_name
                )

                uploaded_file.save(save_path)

                record = File(
                    token=token,
                    original_name=uploaded_file.filename,
                    saved_name=saved_name,
                    file_size=os.path.getsize(save_path)
                )

                db.session.add(record)
                db.session.commit()

                message = "تم رفع الملف بنجاح ✅"

                share_url = url_for(
                    "file_page",
                    token=token,
                    _external=True
                )

        return render_template(
            "upload.html",
            message=message,
            share_url=share_url
        )


    @app.route("/f/<token>")
    def file_page(token):

        print("=" * 40)
        print("TOKEN:", token)

        file = File.query.filter_by(token=token).first()

        print("RESULT:", file)
        print("=" * 40)

        if file is None:
            return f"Token not found: {token}"

        return render_template(
            "file.html",
            file=file
        )


    @app.route("/download/<token>")
    def download(token):

        file = File.query.filter_by(token=token).first()

        if file is None:
            abort(404)

        file.downloads += 1
        db.session.commit()

        return send_from_directory(
            app.config["UPLOAD_FOLDER"],
            file.saved_name,
            as_attachment=True,
            download_name=file.original_name
        )
