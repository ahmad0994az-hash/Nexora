from flask import Flask

from .database import db
from .models import File
from .routes import register_routes


def create_app():

    app = Flask(__name__)

    app.config["SECRET_KEY"] = "nexora-secret"

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///nexora.db"

    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    with app.app_context():
        db.create_all()

    register_routes(app)

    return app
