from datetime import datetime

from .database import db


class File(db.Model):

    __tablename__ = "files"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    token = db.Column(
        db.String(32),
        unique=True,
        nullable=False
    )

    original_name = db.Column(
        db.String(255),
        nullable=False
    )

    saved_name = db.Column(
        db.String(255),
        nullable=False
    )

    file_size = db.Column(
        db.Integer,
        default=0
    )

    downloads = db.Column(
        db.Integer,
        default=0
    )

    uploaded_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )
